

#ifndef Debounce_h
#define Debounce_h

#include <inttypes.h>

class Debounce {
   public:
      Debounce(unsigned long intervalMillis, uint8_t pin);
      void interval(unsigned long intervalMillis);
      int update();
      int read();
      void write(int newState);
  
   private:
      unsigned long mPreviousMillis;
      unsigned long mIntervalMillis;
      uint8_t mState;
      uint8_t mPin;
};

#endif


