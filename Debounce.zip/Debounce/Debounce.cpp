#include "Arduino.h"
#include "Debounce.h"

Debounce::Debounce(unsigned long intervalMillis, uint8_t pin) {
   mIntervalMillis = intervalMillis;
	mPreviousMillis = millis();
	mState = digitalRead(pin);
   mPin = pin;
}

void Debounce::write(int newState) {
   mState = newState;
   digitalWrite(mPin, mState);
}

void Debounce::interval(unsigned long intervalMillis) {
   mIntervalMillis = intervalMillis;
}

int Debounce::update() {
   uint8_t newState = digitalRead(mPin);
	if (mState != newState) {
  	   if (millis() - mPreviousMillis >= mIntervalMillis) {
  			mPreviousMillis = millis();
  			mState = newState;
  			return 1;
      }
   }
   return 0;
}

int Debounce::read() {
	return (int)mState;
}


